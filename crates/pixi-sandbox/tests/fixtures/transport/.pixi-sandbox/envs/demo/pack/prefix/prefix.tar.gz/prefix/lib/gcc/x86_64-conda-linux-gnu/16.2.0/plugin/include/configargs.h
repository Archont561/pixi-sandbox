/* Generated automatically. */
static const char configuration_arguments[] = "../configure --prefix=@PREFIX@ --with-slibdir=@PREFIX@/lib --libdir=@PREFIX@/lib --mandir=@PREFIX@/share/man --build=x86_64-conda-linux-gnu --host=x86_64-conda-linux-gnu --target=x86_64-conda-linux-gnu --enable-languages=c,c++,fortran,objc,obj-c++ --enable-libgomp --disable-libssp --enable-libquadmath --enable-libquadmath-support --disable-nls --disable-bootstrap --disable-multilib --enable-multiarch --enable-long-long --without-zstd --with-native-system-header-dir=/usr/include --with-gxx-include-dir=@PREFIX@/lib/gcc/x86_64-conda-linux-gnu/16.2.0/include/c++ --with-gxx-libcxx-include-dir=@PREFIX@/lib/gcc/x86_64-conda-linux-gnu/16.2.0/../../../../include/c++/v1 --with-pkgversion='conda-forge gcc 16.2.0-7' --with-bugurl=https://github.com/conda-forge/ctng-compilers-feedstock/issues/new/choose --enable-libsanitizer --enable-default-pie --enable-threads=posix --enable-__cxa_atexit --with-sysroot=@PREFIX@/x86_64-conda-linux-gnu/sysroot --with-build-sysroot=/home/conda/feedstock_root/build_artifacts/gcc_compilers_1790300741325/_build_env/x86_64-conda-linux-gnu/sysroot --enable-plugin --enable-lto";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "x86-64" } };
